public class Rectangle extends Shape {
    private double width;
    private double height;
    public Rectangle(double width, double height) {
        super("红色");
        this.width = width;
        this.height = height;
    }
    @Override
    public double getArea() { return width * height; }
}
