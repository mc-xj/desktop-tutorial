public class Triangle extends Shape {
    private double base;
    private double height;
    public Triangle(double base, double height) {
        super("绿色");
        this.base = base;
        this.height = height;
    }
    @Override
    public double getArea() { return base * height / 2; }
}
